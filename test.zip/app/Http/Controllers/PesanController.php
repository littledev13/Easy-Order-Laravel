<?php

namespace App\Http\Controllers;

use App\Models\Menu;
use App\Models\Toko;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\URL;

class PesanController extends Controller
{
    //
    function index(Toko $id_toko)
    {
        // $url = Toko::where('id' . '==' . $id_toko->id)->get();
        return view('{id}.index', [
            'toko' => $id_toko->nama
        ]);
    }
    function showMenu($id_toko, $kategori)
    {
        $menu = Menu::where([
            ['id_toko', '=', $id_toko],
            ['kategori', '=', $kategori],
        ])->get();
        return view('{id}.kategori.kategori', [
            'menu' => $menu
        ]);
    }
}