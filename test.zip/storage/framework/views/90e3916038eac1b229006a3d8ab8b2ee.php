<!-- resources/views/layouts/app.blade.php -->

<html>

<head>
    <title>Easy Order</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/tw-elements.umd.min.js'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/all.css'); ?>
</head>
<?php
    // Mendapatkan nilai angka dari URL
    $angka = request()->segment(1);
    $type = request()->segment(2);
?>

<body class="bg-[#e6e6e6]">
    <div class="md:container mx-auto min-h-screen flex flex-col px-5 py-3">
        <div class="header w-full">
            <p class="font-semibold text-xl text-neutral-700 text-left">EasyOrder</p>
        </div>
        <?php echo $__env->yieldContent('content'); ?>
        <div id="footer"
            class="flex flex-row items-center justify-center gap-5 md:gap-8 fixed bottom-5 left-[50%] right-[50%]">
            <a href="<?php echo e(route('menu', ['id_toko' => $angka, 'kategori' => 'food'])); ?>"
                class="food flex flex-col items-center h-full"><i
                    class="fa-solid fa-burger <?php echo e($type == 'food' ? 'text-slate-300' : 'text-white'); ?> text-2xl"></i><span
                    class="text-gray-500 text-xl">food</span></a>
            <a href="<?php echo e(route('menu', ['id_toko' => $angka, 'kategori' => 'drink'])); ?>"
                class="drink flex flex-col items-center h-full"><i
                    class="fa-solid fa-champagne-glasses <?php echo e($type == 'drink' ? 'text-slate-300' : 'text-white'); ?> text-2xl"></i><span
                    class="text-gray-500 text-xl">drink</span>
            </a>
            <a href="<?php echo e(route('menu', ['id_toko' => $angka, 'kategori' => 'dessert'])); ?>"
                class="dessert flex flex-col items-center h-full"><i
                    class="fa-solid fa-lemon <?php echo e($type == 'dessert' ? 'text-slate-300' : 'text-white'); ?> text-2xl"></i><span
                    class="text-gray-500 text-xl">dessert</span></a>
            <a href="<?php echo e(route('cart', $angka)); ?>"
                class="cart fixed flex justify-center items-center bottom-8 left-5 rounded-full w-16 h-16 <?php echo e($type == 'cart' ? 'bg-neutral-100' : 'bg-neutral-300 '); ?> shadow-md"><i
                    class="fa-solid fa-cart-shopping <?php echo e($type == 'cart' ? 'text-slate-300' : 'text-white '); ?> text-3xl"></i></a>
        </div>

    </div>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/main.js'); ?>
</body>

</html>
<?php /**PATH D:\3 - Kuliah\S7\KP\easy-order\resources\views/{id}/layout.blade.php ENDPATH**/ ?>