//
//
//
//
import {
    Carousel,
    initTE,
    Input,
    Ripple,
    Chart,
    Toast,
    Modal,
    Select,
} from "tw-elements";
initTE({ Carousel, Input, Ripple, Chart, Toast, Modal, Select });
