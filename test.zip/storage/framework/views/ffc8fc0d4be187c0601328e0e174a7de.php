<!-- resources/views/layouts/app.blade.php -->

<html>

<head>
    <title><?php echo $__env->yieldContent('title'); ?> | Easy Order</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/tw-elements.umd.min.js'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/all.css'); ?>
</head>

<body>
    <div class="container mx-auto">
        <?php $__env->startSection('header'); ?>
        <?php echo $__env->yieldSection(); ?>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/main.js'); ?>
</body>

</html>
<?php /**PATH D:\3 - Kuliah\S7\KP\easy-order\resources\views/layouts/app.blade.php ENDPATH**/ ?>