





<?php $__env->startSection('content'); ?>
    <div class="w-full flex flex-col justify-center items-center mt-[37vh]">
        <p class="text-slate-400 text-2xl">Selamat Datang di <?php echo e($toko); ?></p>
        <p class="text-slate-400 text-2xl">Silahkan pilih menu</p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('{id}.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\3 - Kuliah\S7\KP\easy-order\resources\views/{id}/index.blade.php ENDPATH**/ ?>