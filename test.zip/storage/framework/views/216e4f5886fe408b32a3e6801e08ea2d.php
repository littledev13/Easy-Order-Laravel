
<?php
    $angka = request()->segment(1);
?>


<?php $__env->startSection('content'); ?>
    <div
        class="w-full h-full flex flex-col md:flex-row md:flex-wrap justify-center items-center gap-5 md:justify-normal md:items-start md:pb-32">
        <?php $__empty_1 = true; $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <form action="<?php echo e(route('addCart', $angka)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?>
                <div
                    class="card max-w-[400px] h-[140px] rounded-lg bg-white flex flex-row items-center box-content overflow-hidden shadow-md shadow-gray-400  pr-2">

                    <div class="hidden">
                        <input type="text" value="<?php echo e($item->id); ?>" name="id">
                        <input type="text" value="<?php echo e($item->nama); ?>" name="nama">
                        <input type="text" value="<?php echo e($item->harga); ?>" name="harga">
                        
                    </div>

                    <div class="img ">
                        <img src="/img/menu/<?php echo e($item->image_url); ?>" alt="" class="h-[140px]">
                    </div>
                    <div class="details h-full  px-2">
                        <p class="text-xl font-semibold text-neutral-900"><?php echo e($item->nama); ?></p>
                        <p class="text-sm text-gray-500"><?php echo e($item->deskripsi); ?></p>
                    </div>
                    <div class="action flex flex-col items-center gap-5">
                        <button type="submit"
                            class="btn  w-8 h-8 hover:text-slate-400 rounded-full text-slate-200 flex place-items-center justify-center"><i
                                class="fa-solid fa-circle-plus text-2xl"></i></button>
                        <button type="submit"
                            class="btn  w-8 h-8 hover:text-slate-400 rounded-full text-slate-200 flex place-items-center justify-center"><i
                                class="fa-solid fa-circle-minus text-2xl"></i></button>
                    </div>
                </div>
            </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-slate-400 text-2xl mt-[37vh] text-center w-full">Menu belum ada</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('{id}.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\3 - Kuliah\S7\KP\easy-order\resources\views/{id}/{kategori}/index.blade.php ENDPATH**/ ?>