<!-- resources/views/child.blade.php -->



<?php $__env->startSection('title', 'Toko Not Found'); ?>


<?php $__env->startSection('content'); ?>
    <div class="w-full h-full flex flex-col justify-center items-center gap-5">
        <p class="text-2xl text-gray-600">harap scan barcode dari toko untuk memesan</p>
        <p class="text-lg text-gray-400">atau</p>
        <p class="text-2xl text-gray-600">Harap melakukan pemesanan, melalui link yang di sediakan toko</p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\3 - Kuliah\S7\KP\easy-order\resources\views/index.blade.php ENDPATH**/ ?>