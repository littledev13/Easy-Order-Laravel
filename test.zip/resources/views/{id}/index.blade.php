@extends('{id}.layout')

{{-- @section('title', '') --}}



@section('content')
    <div class="w-full flex flex-col justify-center items-center mt-[37vh]">
        <p class="text-slate-400 text-2xl">Selamat Datang di {{ $toko }}</p>
        <p class="text-slate-400 text-2xl">Silahkan pilih menu</p>
    </div>
@endsection
