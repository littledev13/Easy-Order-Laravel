import "./bootstrap";
import { Carousel, initTE, Input, Ripple, initTE, Chart } from "tw-elements";
initTE({ Carousel, Input, Ripple, Chart });
